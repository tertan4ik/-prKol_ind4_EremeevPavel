﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ind4_Eremeev
{
    internal class Song
    {
        private string name;
        private string artist;

        public string Name
        {
            get { return name; }
        }

        public string Artist
        {
            get { return artist; }
        }

        public Song(string name, string artist)
        {
            this.name = name;
            this.artist = artist;
        }
    }
}
