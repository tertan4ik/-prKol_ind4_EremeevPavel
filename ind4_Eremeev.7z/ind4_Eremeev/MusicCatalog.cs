﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ind4_Eremeev
{
    internal class MusicCatalog
    {
        private Hashtable catalog = new Hashtable();

        public Hashtable GetCatalog
        {
            get { return catalog; }
        }

        public void AddDisk(string diskName)
        {
            catalog.Add(diskName, new ArrayList());
        }

        public void Deletedisk(string diskname)
        {
            catalog.Remove(diskname);
        }

        public void Addsong(string diskName, string songname, string artist)
        {
            if (catalog.ContainsKey(diskName))
            {
                ((ArrayList)catalog[diskName]).Add(new Song(songname, artist));
            }
        }

        public void Deletesong(string diskname, string songname)
        {
            ArrayList songs = (ArrayList)catalog[diskname];

            for (int i = 0; i < songs.Count; i++)
            {
                if (((Song)songs[i]).Name == songname)
                {
                    songs.RemoveAt(i);
                    break;
                }
            }
        }
    }
}
