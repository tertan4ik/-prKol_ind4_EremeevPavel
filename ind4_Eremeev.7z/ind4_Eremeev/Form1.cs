﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ind4_Eremeev
{
    public partial class Form1 : Form
    {
        MusicCatalog musicCatalog = new MusicCatalog();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private bool Vvod(TextBox text)
        {
            bool isCorrect = false;

            if (text.Text == "")
            {
                MessageBox.Show("Обнаружены пустые поля", "Error");
                isCorrect = false;
            }
            else
            {
                isCorrect = true;
            }

            return isCorrect;
        }

        private void adddisk_Click(object sender, EventArgs e)
        {
            if (Vvod(textbox1) && !musicCatalog.GetCatalog.ContainsKey(textbox1.Text))
            {
                musicCatalog.AddDisk(textbox1.Text);
                listBox2.Items.Add(textbox1.Text);

                MessageBox.Show("Диск добавлен", "Information");
            }
            else if (musicCatalog.GetCatalog.ContainsKey(textbox1.Text))
            {
                MessageBox.Show("Такой диск уже есть", "Error");
            }
        }

        private void deletedisk_Click(object sender, EventArgs e)
        {
            if (listBox2.SelectedIndex != -1)
            {
                listBox2.Items.RemoveAt(listBox2.SelectedIndex);
                string disk = listBox2.SelectedIndex.ToString();
                musicCatalog.Deletedisk(textbox1.Text);
                MessageBox.Show("Диск удален", "Information");
            }
            else
                MessageBox.Show("Выберите диск");
        }

        private void addsong_Click(object sender, EventArgs e)
        {
            if (Vvod(textbox3) && Vvod(textbox2) && Vvod(textbox4)
                && musicCatalog.GetCatalog.ContainsKey(textbox3.Text))
            {
                try
                {
                    musicCatalog.Addsong(textbox3.Text, textbox2.Text, textbox4.Text);
                    MessageBox.Show("Песня добавлена", "Information");

                    listBox1.Items.Clear();

                    foreach (DictionaryEntry entry in musicCatalog.GetCatalog)
                    {
                        ArrayList songs = (ArrayList)entry.Value;

                        foreach (Song song in songs)
                        {
                            listBox1.Items.Add($"Диск: {entry.Key}; Песня: {song.Name}; Исполнитель: {song.Artist}");
                        }
                    }
                }
                catch (InvalidOperationException ex)
                {
                    MessageBox.Show(ex.Message, "Error");
                }
            }
            else if (!musicCatalog.GetCatalog.ContainsKey(textbox3.Text))
                MessageBox.Show("Диск не обнаружен", "Error");
        }

        private void deleteSong_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex != -1)
            {
                listBox1.Items.RemoveAt(listBox1.SelectedIndex);
                string disk = listBox1.SelectedIndex.ToString();
                musicCatalog.Deletesong(textbox3.Text, textbox2.Text);
            }
            else
                MessageBox.Show("Выберите песню");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string search = textbox4.Text.Trim();
           if (!string.IsNullOrEmpty(search))
            {
                var results = musicCatalog.GetCatalog
                    .Cast<DictionaryEntry>()
                    .SelectMany(entry => ((ArrayList)entry.Value)
                    .Cast<Song>()
                    .Where(song => song.Artist.Contains(search))
                    .Select(song => new { Disk = entry.Key, Song = song }))
                    .ToList();

                listBox1.Items.Clear();

                if (results.Count > 0)
                {
                    foreach (var result in results)
                    {
                        listBox1.Items.Add($"Диск: {result.Disk}; Песня: {result.Song.Name}; Исполнитель: {result.Song.Artist}");
                    }
                }
                else
                {
                    listBox1.Items.Add("Исполнитель не найден");
                }
            }
            else
            {
                MessageBox.Show("Введите имя исполнителя для поиска", "Error");
            }
        }
    }
}
